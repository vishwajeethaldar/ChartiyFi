// PriceLineChart.js
import React from "react";
import {
	LineChart,
	Line,
	XAxis,
	YAxis,
	Tooltip,
	Legend,
	ResponsiveContainer,
} from "recharts";
import { data } from "./data";

const PriceLineChart = () => {
	// Ensure dates are parsed correctly
	const formattedData = data.map((item) => ({
		...item,
		Date: new Date(item.Date).toLocaleDateString(),
	}));

	return (
		<ResponsiveContainer width={"50%"} height={300}>
			<LineChart data={formattedData}>
				<XAxis dataKey="Date" />
				<YAxis />
				<Tooltip />
				<Legend />
				<Line type="monotone" dataKey="TotalPrice" stroke="#82ca9d" />
			</LineChart>
		</ResponsiveContainer>
	);
};

export default PriceLineChart;
