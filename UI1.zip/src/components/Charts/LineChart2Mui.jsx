import { LineChart } from "@mui/x-charts/LineChart";
import { ChartsTooltip } from "@mui/x-charts/ChartsTooltip";
import { Box, Typography } from "@mui/material";

// Process data for both charts
const processChartData = (data) => {
  const monthlyData = {};

  data.forEach(entry => {
    const date = new Date(entry.Date);
    const monthYear = date.toLocaleString('default', { month: 'short' }) + '-' + date.getFullYear();
    
    if (!monthlyData[monthYear]) {
      monthlyData[monthYear] = {
        total: 0,
        count: 0,
        month: monthYear
      };
    }
    
    monthlyData[monthYear].total += entry.PricePerCarat;
    monthlyData[monthYear].count++;
  });

  return Object.values(monthlyData).map(item => ({
    month: item.month,
    averagePrice: Math.round((item.total / item.count) * 100) / 100
  }));
};


const MuiChartExample = ({ data }) => {
    const chartData = processChartData(data);

    return (
			<Box sx={{ height: 400, p: 2 }}>
				<Typography variant="h6" gutterBottom>
					Price Trends (MUI Charts)
				</Typography>
				<LineChart
					xAxis={[
						{
							dataKey: "month",
							scaleType: "point",
							label: "Month",
							tickLabelStyle: { fill: "#666" },
						},
					]}
					yAxis={[
						{
							label: "Price/Carat ($)",
							tickLabelStyle: { fill: "#666" },
						},
					]}
					series={[
						{
							dataKey: "averagePrice",
							label: "Average Price",
							color: "#1976d2",
							showMark: true,
							curve: "linear",
						},
					]}
					dataset={chartData}
					margin={{ left: 70, right: 30, top: 30, bottom: 50 }}
					slotProps={{
						legend: { hidden: true },
						tooltip: {
							slotType: "tooltip",
							chart: {
								sx: {
									".MuiChartsTooltip-cell": { color: "#1976d2" },
									".MuiChartsTooltip-row": { fontSize: "0.875rem" },
								},
							},
						},
					}}
					sx={{
						".MuiLineElement-root": { strokeWidth: 2 },
						".MuiMarkElement-root": { fill: "#1976d2", strokeWidth: 2 },
					}}
				/>
			</Box>
		);
};

export default MuiChartExample;