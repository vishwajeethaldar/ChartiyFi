import {
	BarChart,
	Bar,
	XAxis,
	YAxis,
	CartesianGrid,
	Tooltip,
	Legend,
	ResponsiveContainer,
} from "recharts";
import MultipleStopRoundedIcon from "@mui/icons-material/MultipleStopRounded";
import { Box, IconButton, Paper, Typography } from "@mui/material";
import { useState } from "react";
import AverageTable from "./Parts/AverageTable";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import KeyboardArrowRight from "@mui/icons-material/KeyboardArrowRight";


// console.log(transformedData);
const COLORS = [
	"#0088FE", // Strong Blue
	"#00C49F", // Teal
	"#FFBB28", // Bright Yellow
	"#FF8042", // Strong Orange
	"#D32F2F", // Red
	// "#8E24AA", // Purple
	// "#5E35B1", // Indigo
	// "#3949AB", // Dark Blue
	"#1E88E5", // Blue
	"#039BE5", // Light Blue
	"#00ACC1", // Cyan
	"#00897B", // Turquoise
	// "#43A047", // Green
	// "#7CB342", // Lime Green
	// "#C0CA33", // Olive Green
	"#FDD835", // Bright Yellow
	"#FFB300", // Amber
	"#FB8C00", // Dark Orange
	"#F4511E", // Deep Orange
	"#6D4C41", // Brown
];

// Custom Tooltip Component styled with MUI
// Custom Tooltip Component styled with MUI that shows percentage as well.
const CustomTooltip = ({ active, payload, label }) => {
	if (active && payload && payload.length) {
		// Calculate the total value for the current row (i.e. for this SizeCategory)
		const total = payload.reduce((sum, entry) => sum + entry.value, 0);
		return (
			<Paper
				elevation={3}
				sx={{
					p: 1,
					backgroundColor: "white",
					border: "1px solid #ccc",
					borderRadius: 1,
				}}
			>
				<Typography variant="subtitle2" sx={{ mb: 0.5 }}>
					{`Size Category: ${label}`}
				</Typography>
				{payload.map((entry, index) => {
					const percentage = total ? ((entry.value / total) * 100).toFixed(1) : 0;
					return (
						<Typography
							key={index}
							variant="body2"
							sx={{ color: entry.color }}
						>
							{`${entry.name}: ${entry.value.toFixed(2)} (${percentage}%)`}
						</Typography>
					);
				})}
			</Paper>
		);
	}
	return null;
};



export default function StackedBarChartBySizeCategoryAndModel({ chartData, isExpanded }) {
	const [showTable, setShowTable] = useState(false);
	// For custom legend navigation
	const [legendIndex, setLegendIndex] = useState(0);
	const visibleLegendCount = 5; // Adjust number of visible legend items

	function toggleView() {
		setShowTable(!showTable);
	}

	// Group data by SizeCategory and Model
	const categorisedBySizeCategory = chartData.reduce(
		(acc, item) => {
			const sizeCategory = item.SizeCategory;

			if (!acc.sizeCategory[sizeCategory]) {
				acc.sizeCategory[sizeCategory] = {
					SizeCategory: sizeCategory,
					models: {
						[item.Model]: item.Carats,
					},
					items: [item],
				};
			} else {
				if (!acc.sizeCategory[sizeCategory].models[item.Model]) {
					acc.sizeCategory[sizeCategory].models[item.Model] = item.Carats;
				} else {
					acc.sizeCategory[sizeCategory].models[item.Model] += item.Carats;
				}
				acc.sizeCategory[sizeCategory].items.push(item);
			}

			if (!acc.models[item.Model]) {
				acc.models[item.Model] = item.Model;
			}

			return acc;
		},
		{ sizeCategory: {}, models: {} }
	);

	// Transform data for the chart
	const transformedData = Object.values(
		categorisedBySizeCategory.sizeCategory
	).map((item) => {
		const { SizeCategory, models } = item;
		return {
			SizeCategory,
			...models,
		};
	});

	// Get an array of color keys from the grouped data
	const legendModels = Object.keys(categorisedBySizeCategory.models);

	const handleLegendPrev = () => {
		setLegendIndex((prev) => Math.max(prev - 1, 0));
	};

	const handleLegendNext = () => {
		setLegendIndex((prev) =>
			Math.min(prev + 1, legendModels.length - visibleLegendCount)
		);
	};

	return (
		<Box
			sx={{
				width: "100%",
				height: "100%",
				// display: "flex",
				position: "relative",
			}}
		>
			{isExpanded && (
				<IconButton
					onClick={toggleView}
					sx={{
						position: "absolute",
						right: "20px",
						top: "-30px",
						cursor: "pointer",
						zIndex: 100,
					}}
				>
					<MultipleStopRoundedIcon sx={{ cursor: "pointer" }} />
				</IconButton>
			)}
			{/* Custom Legend placed above the chart */}
			<Box
				sx={{
					display: "flex",
					alignItems: "center",
					justifyContent: "center",
					mb: -2,
				}}
			>
				<Typography>Models</Typography>
				<IconButton onClick={handleLegendPrev} disabled={legendIndex === 0}>
					<KeyboardArrowLeft />
				</IconButton>
				<Box
					sx={{
						display: "flex",
						overflow: "hidden",
						width: "auto",
						mx: 1,
						my: 2,
					}}
				>
					{legendModels
						.slice(legendIndex, legendIndex + visibleLegendCount)
						.map((color, index) => (
							<Box
								key={`legend-${color}`}
								sx={{
									display: "flex",
									alignItems: "center",
									mx: 1,
								}}
							>
								<Box
									sx={{
										width: 10,
										height: 10,
										backgroundColor:
											COLORS[(index + legendIndex) % COLORS.length],
										mr: 0.5,
									}}
								/>
								<Typography variant="body2">{color}</Typography>
							</Box>
						))}
				</Box>
				<IconButton
					onClick={handleLegendNext}
					disabled={legendIndex >= legendModels.length - visibleLegendCount}
				>
					<KeyboardArrowRight />
				</IconButton>
			</Box>
			<Box
				sx={{
					width: "98%",
					height: "80%",
					display: "flex",
				}}
			>
				<ResponsiveContainer width="100%" height={"100%"}>
					<BarChart
						width={500}
						height={300}
						data={transformedData}
						margin={{
							top: 20,
							right: 30,
							left: 20,
							bottom: 5,
						}}
					>
						<CartesianGrid strokeDasharray="3 3" />
						<XAxis dataKey="SizeCategory" />
						<YAxis />
						<Tooltip content={<CustomTooltip />} />
						{Object.keys(categorisedBySizeCategory.models).map(
							(color, index) => (
								<Bar
									key={index}
									dataKey={color}
									stackId="a"
									fill={COLORS[index % COLORS.length]}
								/>
							)
						)}
					</BarChart>
				</ResponsiveContainer>
				{showTable && (
					<Box sx={{ width: "50%", marginTop: "70px" }}>
						<AverageTable data={categorisedBySizeCategory.sizeCategory} />
					</Box>
				)}
			</Box>
		</Box>
	);
}
