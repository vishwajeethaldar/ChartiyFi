import {
	LineChart,
	Line,
	XAxis,
	YAxis,
	CartesianGrid,
	Tooltip,
	ResponsiveContainer,
    LabelList,
} from "recharts";
import PropTypes from "prop-types";
import MultipleStopRoundedIcon from "@mui/icons-material/MultipleStopRounded";
import { Box, IconButton } from "@mui/material";
import { useState } from "react";
import AverageTable from "./Parts/AverageTable2";

const processChartData = (data) => {
	const monthlyData = {};
    const months = [
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec",
		];

	data.forEach((entry) => {
		const date = new Date(entry.Date);
		const monthYear = months[date.getMonth()];

		if (!monthlyData[monthYear]) {
			monthlyData[monthYear] = {
				total: 0,
				count: 0,
				month: monthYear,
				items:[]
			};
		} 

		monthlyData[monthYear].total += entry.PricePerCarat;
		monthlyData[monthYear].count++;
		monthlyData[monthYear].items.push(entry);
		
	});

	return Object.values(monthlyData)
		.map((item) => ({
			month: item.month,
			averagePrice: Math.round((item.total / item.count) * 100) / 100,
			items: item.items
		}))
};

const RechartsExample = ({ data, isExpanded = false }) => {
	const [showTable, setShowTable] = useState(false);
	const chartData = processChartData(data);

	function toggleView() {
		setShowTable(!showTable);
	}

	return (
		<Box
			sx={{
				width: "100%",
				height: "100%",
				display: "flex",
				position: "relative",
			}}
		>
			{isExpanded && (
				<IconButton
					onClick={toggleView}
					sx={{
						position: "absolute",
						right: "20px",
						top: "-40px",
						cursor: "pointer",
						zIndex: 100,
					}}
				>
					<MultipleStopRoundedIcon sx={{ cursor: "pointer" }} />
				</IconButton>
			)}
			<ResponsiveContainer width={showTable ? "50%" : "100%"} height="90%">
				<LineChart
					outerRadius={isExpanded && showTable ? 150 : isExpanded ? 250 : 150}
					data={chartData}
				>
					<CartesianGrid strokeDasharray="3 3" />
					<XAxis
						dataKey="month"
						tick={{ fill: "#666" }}
						label={{
							value: "Month",
							position: "bottom",
							fill: "#444",
						}}
					/>
					<YAxis
						label={{
							value: "Price/Carat ($)",
							angle: -90,
							position: "left",
							fill: "#444",
						}}
					/>
					<Tooltip
						contentStyle={{
							backgroundColor: "#fff",
							border: "1px solid #ddd",
							borderRadius: "4px",
						}}
					/>
					<Line
						type="monotone"
						dataKey="averagePrice"
						stroke="#1976d2"
						strokeWidth={2}
						dot={{ fill: "#1976d2", strokeWidth: 2 }}
						activeDot={{ r: 6 }}
					>
						<LabelList
							dataKey="averagePrice"
							position="top"
							formatter={(value) => `${(value / 1000).toFixed(1)}k`}
							style={{ fill: "#1976d2", fontSize: 12 }}
						/>
					</Line>
				</LineChart>
			</ResponsiveContainer>
			{showTable && (
				<Box sx={{ width: "50%", marginTop: "70px" }}>
					<AverageTable data={chartData} />
				</Box>
			)}
		</Box>
	);
};

RechartsExample.propTypes = {
	data: PropTypes.array,
	isExpanded: PropTypes.bool,
};
export default RechartsExample;
