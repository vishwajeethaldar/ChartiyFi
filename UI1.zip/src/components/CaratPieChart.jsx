// CaratPieChart.js
import React from "react";
import {
	PieChart,
	Pie,
	Tooltip,
	Legend,
	Cell,
	ResponsiveContainer,
} from "recharts";
import { data } from "./data";

const CaratPieChart = () => {
	// Aggregate carats by colour
	const caratsByColour = data.reduce((acc, item) => {
		const colour = item.Colour || "Unknown";
		acc[colour] = (acc[colour] || 0) + item.Carats;
		return acc;
	}, {});

	const pieData = Object.keys(caratsByColour).map((colour) => ({
		name: colour,
		value: caratsByColour[colour],
	}));

	const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

	return (
		<ResponsiveContainer width={"50%"} height={300}>
			<PieChart>
				<Tooltip />
				<Legend />
				<Pie
					data={pieData}
					dataKey="value"
					nameKey="name"
					outerRadius={100}
					fill="#8884d8"
					label
				>
					{pieData.map((entry, index) => (
						<Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
					))}
				</Pie>
			</PieChart>
		</ResponsiveContainer>
	);
};

export default CaratPieChart;
