const ChartDisplayModal = ({ onClose, children }) => {
	return (
		<div
			style={{
				position: "fixed",
				top: 0,
				left: 0,
				width: "100%",
				height: "100%",
				backgroundColor: "rgba(0,0,0,0.5)",
				display: "flex",
				justifyContent: "center",
				alignItems: "center",
				zIndex: 1000,
			}}
		>
			<div
				style={{
					position: "relative",
					width: "90%",
					height: "90%",
					backgroundColor: "#fff",
					borderRadius: "12px",
					padding: "20px",
					boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
				}}
			>
				<button
					onClick={onClose}
					style={{
						position: "absolute",
						top: "10px",
						right: "10px",
						backgroundColor: "transparent",
						border: "none",
						cursor: "pointer",
						fontSize: "16px",
					}}
				>
					Close
				</button>
				<div style={{ width: "100%", height: "100%" }}>{children}</div>
			</div>
		</div>
	);
};


export default ChartDisplayModal;

