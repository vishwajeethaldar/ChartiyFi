
// QuantityBarChart.js
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { data } from './data';

const QuantityBarChart = () => (
  <ResponsiveContainer width={300} height={300}>
    <BarChart data={data}>
      <XAxis dataKey="SizeCategory" />
      <YAxis />
      <Tooltip />
      <Legend />
      <Bar dataKey="Quantity" fill="#8884d8" />
    </BarChart>
  </ResponsiveContainer>
);

export default QuantityBarChart;
