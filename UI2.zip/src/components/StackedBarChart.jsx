// StackedBarChart.js
import React from "react";
import {
	BarChart,
	Bar,
	XAxis,
	YAxis,
	Tooltip,
	Legend,
	ResponsiveContainer,
} from "recharts";
import { data } from "./data";

const StackedBarChart = () => {
	// Aggregate data by SizeCategory and Quality
	const aggregatedData = data.reduce((acc, item) => {
		const category = item.SizeCategory;
		const quality = `Quality${item.Quality}`;
		if (!acc[category]) {
			acc[category] = {
				SizeCategory: category,
				Quality1: 0,
				Quality2: 0,
				Quality3: 0,
				Quality4: 0,
			};
		}
		acc[category][quality] += item.TotalPrice;
		return acc;
	}, {});

	const chartData = Object.values(aggregatedData);

	return (
		<ResponsiveContainer width="100%" height={400}>
			<BarChart data={chartData}>
				<XAxis dataKey="SizeCategory" />
				<YAxis />
				<Tooltip />
				<Legend />
				<Bar dataKey="Quality1" stackId="a" fill="#8884d8" />
				<Bar dataKey="Quality2" stackId="a" fill="#82ca9d" />
				<Bar dataKey="Quality3" stackId="a" fill="#ffc658" />
				<Bar dataKey="Quality4" stackId="a" fill="#ff7300" />
			</BarChart>
		</ResponsiveContainer>
	);
};

export default StackedBarChart;
