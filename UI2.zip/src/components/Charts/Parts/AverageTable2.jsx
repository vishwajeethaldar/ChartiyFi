import PropTypes from "prop-types"
import  { useState } from "react";
import {
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	IconButton,
	Paper,
	Box,
	Typography,
	// TableFooter,
	// TablePagination,
	// TableSortLabel,
} from "@mui/material";
import { KeyboardArrowDown, KeyboardArrowUp } from "@mui/icons-material";

// A single row component that renders its details as an overlay.
const QualityRow = ({ row, isOpen, toggleExpand, rowIndex }) => {
	return (
		<TableRow hover sx={{ position: "relative" }}>
			<TableCell>{rowIndex + 1}</TableCell>
			<TableCell>{row.month}</TableCell>
			<TableCell>{row.averagePrice}</TableCell>
			<TableCell align="center">
				<IconButton size="small" onClick={() => toggleExpand(row.month)}>
					{isOpen ? <KeyboardArrowUp /> : <KeyboardArrowDown />}
				</IconButton>
			</TableCell>
			{isOpen && (
				<Box
					sx={{
						position: "absolute",
						top: "100%",
						left: 0,
						right: 0,
						background: "white",
						border: "1px solid #ccc",
						borderRadius: 1,
						maxHeight: 300,
						overflowX: "auto",
						overflowY: "auto",
						zIndex: 1,
						mt: 1,
						boxShadow: 3,
					}}
				>
					<Box sx={{ position: "relative", p: 1 }}>
						{/* Close button within the overlay */}
						<IconButton
							size="small"
							onClick={() => toggleExpand(row.month)}
							sx={{ position: "absolute", top: 4, right: 4 }}
							aria-label="collapse details"
						>
							<KeyboardArrowUp />
						</IconButton>
						<Typography variant="h6" gutterBottom>
							Details
						</Typography>
						<Table size="small" aria-label="details">
							<TableHead>
								<TableRow>
									<TableCell sx={{ fontWeight: "bold" }}>Sr.</TableCell>
									<TableCell sx={{ fontWeight: "bold" }}>Company</TableCell>
									<TableCell sx={{ fontWeight: "bold" }}>ParcelId</TableCell>
									<TableCell sx={{ fontWeight: "bold" }}>ParcelName</TableCell>
									<TableCell sx={{ fontWeight: "bold" }}>Model</TableCell>
									<TableCell sx={{ fontWeight: "bold" }}>DealName</TableCell>
									<TableCell sx={{ fontWeight: "bold" }}>Carats</TableCell>
									<TableCell sx={{ fontWeight: "bold" }}>Quantity</TableCell>
									<TableCell sx={{ fontWeight: "bold" }}>TotalPrice</TableCell>
									<TableCell sx={{ fontWeight: "bold" }}>
										AdjustedCarats
									</TableCell>
									<TableCell sx={{ fontWeight: "bold" }}>
										AdjustedTotalPrice
									</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{row.items.map((item, index) => (
									<TableRow key={index} hover>
										<TableCell>{index + 1}</TableCell>
										<TableCell>{item.Company}</TableCell>
										<TableCell>{item.ParcelId}</TableCell>
										<TableCell>{item.ParcelName}</TableCell>
										<TableCell>{item.Model}</TableCell>
										<TableCell>{item.DealName}</TableCell>
										<TableCell>{item.Carats}</TableCell>
										<TableCell>{item.Quantity}</TableCell>
										<TableCell>{item.TotalPrice}</TableCell>
										<TableCell>{item.AdjustedCarats}</TableCell>
										<TableCell>{item.AdjustedTotalPrice}</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>
					</Box>
				</Box>
			)}
		</TableRow>
	);
};

QualityRow.propTypes = {
	row: PropTypes.object.isRequired,
	isOpen: PropTypes.bool.isRequired,
	toggleExpand: PropTypes.func.isRequired,
	rowIndex:PropTypes.number.isRequired
};

const AverageTable = ({ data }) => {
	const [openRows, setOpenRows] = useState({});

  const toggleExpand = (quality) => {
		setOpenRows((prev) => ({
			...prev,
			[quality]: !prev[quality],
		}));
	};

	return (
		<TableContainer
			component={Paper}
			sx={{ mt: -6, position: "relative", maxHeight: "70vh" }}
		>
			<Table aria-label="quality table">
				<TableHead sx={{ backgroundColor: "primary.main" }}>
					<TableRow>
						<TableCell sx={{ color: "white", fontWeight: "bold" }}>
							Sr.
						</TableCell>
						<TableCell sx={{ color: "white", fontWeight: "bold" }}>
							Month
						</TableCell>
						<TableCell sx={{ color: "white", fontWeight: "bold" }}>
							Average Price
						</TableCell>
						<TableCell
							sx={{ color: "white", fontWeight: "bold" }}
							align="center"
						>
							Expand
						</TableCell>
					</TableRow>
				</TableHead>
				<TableBody>
					{data.map((row, rowIndex) => (
						<QualityRow
							key={row.month}
							row={row}
							isOpen={!!openRows[row.month]}
							toggleExpand={toggleExpand}
							rowIndex={rowIndex}
						/>
					))}
				</TableBody>
			</Table>
		</TableContainer>
	);
};

AverageTable.propTypes = {
	data: PropTypes.array.isRequired,
};

export default AverageTable;
