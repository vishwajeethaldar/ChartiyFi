import { Box, IconButton, Paper, Typography } from "@mui/material";
import { useState } from "react";
import {
	BarChart,
	Bar,
	XAxis,
	YAxis,
	CartesianGrid,
	Tooltip,
	Legend,
	ResponsiveContainer,
	LabelList,
} from "recharts";
import MultipleStopRoundedIcon from "@mui/icons-material/MultipleStopRounded";
import AverageTable from "./Parts/AverageTable";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import KeyboardArrowRight from "@mui/icons-material/KeyboardArrowRight";
import PropTypes from "prop-types";


// const COLORS = [
// 	"#0088FE",
// 	"#00C49F",
// 	"#FFBB28",
// 	"#FF8042",
// 	"#FF4563",
// 	"#FF4F63",
// 	"#FF45F3",
// 	"#FFF5F3",
// ];

const COLORS = [
	"#0088FE", // Strong Blue
	"#00C49F", // Teal
	"#FFBB28", // Bright Yellow
	"#FF8042", // Strong Orange
	"#D32F2F", // Red
	"#8E24AA", // Purple
	"#5E35B1", // Indigo
	"#3949AB", // Dark Blue
	"#1E88E5", // Blue
	"#039BE5", // Light Blue
	"#00ACC1", // Cyan
	"#00897B", // Turquoise
	"#43A047", // Green
	"#7CB342", // Lime Green
	"#C0CA33", // Olive Green
	"#FDD835", // Bright Yellow
	"#FFB300", // Amber
	"#FB8C00", // Dark Orange
	"#F4511E", // Deep Orange
	"#6D4C41", // Brown
];
const CustomTooltip = ({ active, payload, label }) => {
	if (active && payload && payload.length) {
		// Calculate the total value for the current row (i.e. for this SizeCategory)
		const total = payload.reduce((sum, entry) => sum + entry.value, 0);
		return (
			<Paper
				elevation={3}
				sx={{
					p: 1,
					backgroundColor: "white",
					border: "1px solid #ccc",
					borderRadius: 1,
				}}
			>
				<Typography variant="subtitle2" sx={{ mb: 0.5 }}>
					{`Size Category: ${label}`}
				</Typography>
				{payload.map((entry, index) => {
					const percentage = total
						? ((entry.value / total) * 100).toFixed(1)
						: 0;
					return (
						<Typography key={index} variant="body2" sx={{ color: entry.color }}>
							{`${entry.name}: ${entry.value.toFixed(2)} (${percentage}%)`}
						</Typography>
					);
				})}
			</Paper>
		);
	}
	return null;
};


 function StackedBarChart({ isExpanded, chartData }) {
	const [showTable, setShowTable] = useState(false);

	// For custom legend navigation
	const [legendIndex, setLegendIndex] = useState(0);
	const visibleLegendCount = 5; // Adjust number of visible legend items


	// Group data by SizeCategory and Colour
	const categorisedBySizeCategory = chartData.reduce(
		(acc, item) => {
			const sizeCategory = item.SizeCategory;

			if (!acc.sizeCategory[sizeCategory]) {
				acc.sizeCategory[sizeCategory] = {
					SizeCategory: sizeCategory,
					colors: {
						[item.Colour]: item.Carats,
					},
					items: [item],
				};
			} else {
				if (!acc.sizeCategory[sizeCategory].colors[item.Colour]) {
					acc.sizeCategory[sizeCategory].colors[item.Colour] = item.Carats;
				} else {
					acc.sizeCategory[sizeCategory].colors[item.Colour] += item.Carats;
				}
				acc.sizeCategory[sizeCategory].items.push(item);
			}

			if (!acc.colors[item.Colour]) {
				acc.colors[item.Colour] = item.Colour;
			}

			return acc;
		},
		{ sizeCategory: {}, colors: {} }
	);

	// Transform data for the chart
	const transformedData = Object.values(
		categorisedBySizeCategory.sizeCategory
	).map((item) => {
		const { SizeCategory, colors } = item;
		return {
			SizeCategory,
			...colors,
		};
	});

	// Get an array of color keys from the grouped data
	const legendColors = Object.keys(categorisedBySizeCategory.colors);

		const handleLegendPrev = () => {
			setLegendIndex((prev) => Math.max(prev - 1, 0));
		};

		const handleLegendNext = () => {
			setLegendIndex((prev) =>
				Math.min(prev + 1, legendColors.length - visibleLegendCount)
			);
		};

	
	function toggleView() {
		setShowTable(!showTable);
	}

	return (
		<Box
			sx={{
				width: "100%",
				height: "100%",
				// display: "flex",
				position: "relative",
			}}
		>
			{isExpanded && (
				<IconButton
					onClick={toggleView}
					sx={{
						position: "absolute",
						right: "20px",
						top: "-40px",
						cursor: "pointer",
						zIndex: 100,
					}}
				>
					<MultipleStopRoundedIcon sx={{ cursor: "pointer" }} />
				</IconButton>
			)}
			{/* Custom Legend placed above the chart */}
			<Box
				sx={{
					display: "flex",
					alignItems: "center",
					justifyContent: "center",
					mb: -2,
				}}
			>
				<Typography>Colors</Typography>
				<IconButton onClick={handleLegendPrev} disabled={legendIndex === 0}>
					<KeyboardArrowLeft />
				</IconButton>
				<Box
					sx={{
						display: "flex",
						overflow: "hidden",
						width: "auto",
						mx: 1,
					}}
				>
					{legendColors
						.slice(legendIndex, legendIndex + visibleLegendCount)
						.map((color, index) => (
							<Box
								key={`legend-${color}`}
								sx={{
									display: "flex",
									alignItems: "center",
									mx: 1,
								}}
							>
								<Box
									sx={{
										width: 10,
										height: 10,
										backgroundColor:
											COLORS[(index + legendIndex) % COLORS.length],
										mr: 0.5,
									}}
								/>
								<Typography variant="body2">{color}</Typography>
							</Box>
						))}
				</Box>
				<IconButton
					onClick={handleLegendNext}
					disabled={legendIndex >= legendColors.length - visibleLegendCount}
				>
					<KeyboardArrowRight />
				</IconButton>
			</Box>

			<Box
				sx={{
					width: "98%",
					height: "80%",
					display: "flex",
				}}
			>
				<ResponsiveContainer width="100%" height={"100%"}>
					<BarChart
						width={500}
						height={250}
						outerRadius={isExpanded && showTable ? 150 : isExpanded ? 250 : 150}
						data={transformedData}
						margin={{
							top: 20,
							right: 30,
							left: 20,
							bottom: 5,
						}}
					>
						<CartesianGrid strokeDasharray="3 3" />
						<XAxis dataKey="SizeCategory" />
						<YAxis />
						<Tooltip content={<CustomTooltip/>}/>
						{Object.keys(categorisedBySizeCategory.colors).map(
							(color, index) => (
								<Bar
									key={index}
									dataKey={color}
									stackId="a"
									fill={COLORS[index % COLORS.length]}
								/>
							)
						)}
						
					</BarChart>
				</ResponsiveContainer>
				{showTable && (
					<Box sx={{ width: "50%", marginTop: "70px" }}>
						<AverageTable data={categorisedBySizeCategory.sizeCategory} />
					</Box>
				)}
			</Box>
		</Box>
	);
}


StackedBarChart.prototype = {
	isExpanded: PropTypes.bool.isRequired,
	chartData: PropTypes.array.isRequired,
};

export default StackedBarChart;


// import { Box, IconButton, Paper, Typography } from "@mui/material";
// import { useState } from "react";
// import {
// 	BarChart,
// 	Bar,
// 	XAxis,
// 	YAxis,
// 	CartesianGrid,
// 	Tooltip,
// 	ResponsiveContainer,
// 	LabelList,
// } from "recharts";
// import MultipleStopRoundedIcon from "@mui/icons-material/MultipleStopRounded";
// import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
// import KeyboardArrowRight from "@mui/icons-material/KeyboardArrowRight";
// import PropTypes from "prop-types";
// import AverageTable from "./Parts/AverageTable";

// // A palette of colors for the bars/legend.
// const COLORS = [
// 	"#0088FE",
// 	"#00C49F",
// 	"#FFBB28",
// 	"#FF8042",
// 	"#D32F2F",
// 	"#8E24AA",
// 	"#5E35B1",
// 	"#3949AB",
// 	"#1E88E5",
// 	"#039BE5",
// 	"#00ACC1",
// 	"#00897B",
// 	"#43A047",
// 	"#7CB342",
// 	"#C0CA33",
// 	"#FDD835",
// 	"#FFB300",
// 	"#FB8C00",
// 	"#F4511E",
// 	"#6D4C41",
// ];

// // Helper function to adjust brightness of a hex color.
// // A positive percent lightens the color; a negative percent darkens it.
// function shadeColor(color, percent) {
// 	let num = parseInt(color.slice(1), 16),
// 		amt = Math.round(2.55 * percent),
// 		R = (num >> 16) + amt,
// 		G = ((num >> 8) & 0x00ff) + amt,
// 		B = (num & 0x0000ff) + amt;
// 	return (
// 		"#" +
// 		(
// 			0x1000000 +
// 			(R < 255 ? (R < 1 ? 0 : R) : 255) * 0x10000 +
// 			(G < 255 ? (G < 1 ? 0 : G) : 255) * 0x100 +
// 			(B < 255 ? (B < 1 ? 0 : B) : 255)
// 		)
// 			.toString(16)
// 			.slice(1)
// 	);
// }

// // Custom 3D bar shape to simulate depth.
// // It draws three surfaces: top face, side face, and front face.
// const render3DBar = (props) => {
// 	const { x, y, width, height, fill } = props;
// 	// Offsets for the 3D effect (adjust these for desired perspective)
// 	const offsetX = 5;
// 	const offsetY = -5;
// 	return (
// 		<g>
// 			{/* Top face */}
// 			<polygon
// 				points={`
//           ${x},${y} 
//           ${x + offsetX},${y + offsetY} 
//           ${x + width + offsetX},${y + offsetY} 
//           ${x + width},${y}
//         `}
// 				fill={shadeColor(fill, 20)}
// 			/>
// 			{/* Side face */}
// 			<polygon
// 				points={`
//           ${x + width},${y} 
//           ${x + width + offsetX},${y + offsetY} 
//           ${x + width + offsetX},${y + height + offsetY} 
//           ${x + width},${y + height}
//         `}
// 				fill={shadeColor(fill, -20)}
// 			/>
// 			{/* Front face */}
// 			<rect x={x} y={y} width={width} height={height} fill={fill} />
// 		</g>
// 	);
// };

// // Custom tooltip for the bar chart.
// const CustomTooltip = ({ active, payload, label }) => {
// 	if (active && payload && payload.length) {
// 		// Calculate total value for the current row.
// 		const total = payload.reduce((sum, entry) => sum + entry.value, 0);
// 		return (
// 			<Paper
// 				elevation={3}
// 				sx={{
// 					p: 1,
// 					backgroundColor: "white",
// 					border: "1px solid #ccc",
// 					borderRadius: 1,
// 				}}
// 			>
// 				<Typography variant="subtitle2" sx={{ mb: 0.5 }}>
// 					{`Size Category: ${label}`}
// 				</Typography>
// 				{payload.map((entry, index) => {
// 					const percentage = total
// 						? ((entry.value / total) * 100).toFixed(1)
// 						: 0;
// 					return (
// 						<Typography key={index} variant="body2" sx={{ color: entry.color }}>
// 							{`${entry.name}: ${entry.value.toFixed(2)} (${percentage}%)`}
// 						</Typography>
// 					);
// 				})}
// 			</Paper>
// 		);
// 	}
// 	return null;
// };

// CustomTooltip.propTypes = {
// 	active: PropTypes.bool,
// 	payload: PropTypes.array,
// 	label: PropTypes.string,
// };

// // Process the raw chart data into grouped data.
// const processChartData = (chartData) => {
// 	// Group data by SizeCategory and accumulate Carats per Colour.
// 	const categorisedBySizeCategory = chartData.reduce(
// 		(acc, item) => {
// 			const sizeCategory = item.SizeCategory;
// 			if (!acc.sizeCategory[sizeCategory]) {
// 				acc.sizeCategory[sizeCategory] = {
// 					SizeCategory: sizeCategory,
// 					colors: { [item.Colour]: item.Carats },
// 					items: [item],
// 				};
// 			} else {
// 				acc.sizeCategory[sizeCategory].colors[item.Colour] =
// 					(acc.sizeCategory[sizeCategory].colors[item.Colour] || 0) +
// 					item.Carats;
// 				acc.sizeCategory[sizeCategory].items.push(item);
// 			}
// 			if (!acc.colors[item.Colour]) {
// 				acc.colors[item.Colour] = item.Colour;
// 			}
// 			return acc;
// 		},
// 		{ sizeCategory: {}, colors: {} }
// 	);

// 	// Transform into an array suitable for the BarChart.
// 	const transformedData = Object.values(
// 		categorisedBySizeCategory.sizeCategory
// 	).map((item) => ({
// 		SizeCategory: item.SizeCategory,
// 		...item.colors,
// 	}));

// 	return {
// 		transformedData,
// 		legendColors: Object.keys(categorisedBySizeCategory.colors),
// 		categorisedBySizeCategory,
// 	};
// };

// // Custom interactive legend for the stacked bar chart.
// const CustomBarLegend = ({ legendColors, visibleColors, onLegendClick }) => {
// 	return (
// 		<Box
// 			sx={{
// 				display: "flex",
// 				alignItems: "center",
// 				justifyContent: "center",
// 				mb: 1,
// 			}}
// 		>
// 			{legendColors.map((col, index) => {
// 				const isVisible = visibleColors[col];
// 				return (
// 					<Box
// 						key={`legend-${col}`}
// 						onClick={() => onLegendClick(col)}
// 						sx={{
// 							display: "flex",
// 							alignItems: "center",
// 							mx: 1,
// 							cursor: "pointer",
// 							opacity: isVisible ? 1 : 0.6,
// 							transform: isVisible ? "scale(1)" : "scale(0.9)",
// 							transition: "transform 0.2s, opacity 0.2s",
// 							background: isVisible
// 								? "linear-gradient(145deg, #fff, #e6e6e6)"
// 								: "linear-gradient(145deg, #ccc, #aaa)",
// 							boxShadow: isVisible
// 								? "3px 3px 5px #aaa, -3px -3px 5px #fff"
// 								: "none",
// 							p: 0.5,
// 							borderRadius: "4px",
// 						}}
// 					>
// 						<Box
// 							sx={{
// 								width: 10,
// 								height: 10,
// 								backgroundColor: isVisible
// 									? COLORS[legendColors.indexOf(col) % COLORS.length]
// 									: "#ccc",
// 								mr: 0.5,
// 								borderRadius: "50%",
// 							}}
// 						/>
// 						<Typography variant="body2">{col}</Typography>
// 					</Box>
// 				);
// 			})}
// 		</Box>
// 	);
// };

// CustomBarLegend.propTypes = {
// 	legendColors: PropTypes.array.isRequired,
// 	visibleColors: PropTypes.object.isRequired,
// 	onLegendClick: PropTypes.func.isRequired,
// };

// const StackedBarChart = ({ isExpanded, chartData }) => {
// 	const { transformedData, legendColors, categorisedBySizeCategory } =
// 		processChartData(chartData);
// 	// Initialize visibility for each legend color.
// 	const initialVisibility = {};
// 	legendColors.forEach((col) => {
// 		initialVisibility[col] = true;
// 	});
// 	const [visibleColors, setVisibleColors] = useState(initialVisibility);
// 	const [legendIndex, setLegendIndex] = useState(0);
// 	const visibleLegendCount = 5; // Number of legend items visible at a time.
// 	const [showTable, setShowTable] = useState(false);

// 	const handleLegendPrev = () => {
// 		setLegendIndex((prev) => Math.max(prev - 1, 0));
// 	};

// 	const handleLegendNext = () => {
// 		setLegendIndex((prev) =>
// 			Math.min(prev + 1, legendColors.length - visibleLegendCount)
// 		);
// 	};

// 	const onLegendClick = (col) => {
// 		setVisibleColors((prev) => ({
// 			...prev,
// 			[col]: !prev[col],
// 		}));
// 	};

// 	function toggleView() {
// 		setShowTable(!showTable);
// 	}

// 	return (
// 		<Box
// 			sx={{
// 				width: "100%",
// 				height: "100%",
// 				position: "relative",
// 			}}
// 		>
// 			{isExpanded && (
// 				<IconButton
// 					onClick={toggleView}
// 					sx={{
// 						position: "absolute",
// 						right: "20px",
// 						top: "-40px",
// 						cursor: "pointer",
// 						zIndex: 100,
// 					}}
// 				>
// 					<MultipleStopRoundedIcon />
// 				</IconButton>
// 			)}
// 			{/* Custom Legend Navigation */}
// 			<Box
// 				sx={{
// 					display: "flex",
// 					alignItems: "center",
// 					justifyContent: "center",
// 					mb: 1,
// 				}}
// 			>
// 				<Typography variant="body2">Colors</Typography>
// 				<IconButton onClick={handleLegendPrev} disabled={legendIndex === 0}>
// 					<KeyboardArrowLeft />
// 				</IconButton>
// 				<Box
// 					sx={{
// 						display: "flex",
// 						overflow: "hidden",
// 						width: "auto",
// 						mx: 1,
// 					}}
// 				>
// 					{legendColors
// 						.slice(legendIndex, legendIndex + visibleLegendCount)
// 						.map((col) => (
// 							<Box key={`legend-${col}`}>
// 								<CustomBarLegend
// 									legendColors={[col]}
// 									visibleColors={visibleColors}
// 									onLegendClick={onLegendClick}
// 								/>
// 							</Box>
// 						))}
// 				</Box>
// 				<IconButton
// 					onClick={handleLegendNext}
// 					disabled={legendIndex >= legendColors.length - visibleLegendCount}
// 				>
// 					<KeyboardArrowRight />
// 				</IconButton>
// 			</Box>

// 			<Box
// 				sx={{
// 					width: "98%",
// 					height: "80%",
// 					display: "flex",
// 				}}
// 			>
// 				<ResponsiveContainer width="100%" height="100%">
// 					<BarChart
// 						data={transformedData}
// 						margin={{
// 							top: 20,
// 							right: 30,
// 							left: 20,
// 							bottom: 5,
// 						}}
// 					>
// 						<CartesianGrid strokeDasharray="3 3" />
// 						<XAxis dataKey="SizeCategory" />
// 						<YAxis />
// 						<Tooltip content={<CustomTooltip />} />
// 						{/* Render a Bar for each color if visible */}
// 						{legendColors.map((col, index) => {
// 							if (!visibleColors[col]) return null;
// 							return (
// 								<Bar
// 									key={col}
// 									dataKey={col}
// 									stackId="a"
// 									fill={COLORS[index % COLORS.length]}
// 									shape={render3DBar}
// 								>
// 									<LabelList
// 										dataKey={col}
// 										position="top"
// 										style={{
// 											fill: COLORS[index % COLORS.length],
// 											fontSize: 10,
// 										}}
// 									/>
// 								</Bar>
// 							);
// 						})}
// 					</BarChart>
// 				</ResponsiveContainer>
// 				{showTable && (
// 					<Box sx={{ width: "50%", marginTop: "70px" }}>
// 						<AverageTable data={categorisedBySizeCategory.sizeCategory} />
// 					</Box>
// 				)}
// 			</Box>
// 		</Box>
// 	);
// };

// StackedBarChart.propTypes = {
// 	isExpanded: PropTypes.bool.isRequired,
// 	chartData: PropTypes.array.isRequired,
// };

// export default StackedBarChart;
