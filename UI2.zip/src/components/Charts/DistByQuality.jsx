// import {
// 	PieChart,
// 	Pie,
// 	Cell,
// 	Tooltip,
// 	Legend,
// 	ResponsiveContainer,
// } from "recharts";
// import {Box, Typography, Tooltip as MuiTooltip, IconButton} from "@mui/material";
// import PropTypes from "prop-types";
// import { useState } from "react";
// import MultipleStopRoundedIcon from "@mui/icons-material/MultipleStopRounded";
// import QualityTable from "./Parts/QualityTable";

// // Generate color dynamically
// const COLORS = [
//   '#0088FE',
//   '#00C49F',
//   '#FFBB28',
//   '#FF8042',
//   '#FF4563',
//   '#FF4F63',
//   '#FF45F3',
//   '#FFF5F3',
// ];

// // Custom Tooltip
// const CustomTooltip = ({ active, payload }) => {
//   if (active && payload && payload.length) {
//     return (
//       <div
//         style={{
//           backgroundColor: "#ffffff",
//           padding: "10px",
//           border: "1px solid #e2e8f0",
//           borderRadius: "8px",
//           boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
//         }}
//       >
//         <p style={{ margin: 0, color: "#4A5568" }}>
//           Quality: <strong>{payload[0].name}</strong>
//         </p>
//         <p style={{ margin: 0, color: "#4A5568" }}>
//           Quantity: <strong>{payload[0].value}</strong>
//         </p>
//       </div>
//     );
//   }
//   return null;
// };


// const CustomLegend = ({ payload = [], data }) => {

// 	return (
// 		<Box
// 			display="flex"
// 			justifyContent="center"
// 			p={0}
// 			component="ul"
// 			sx={{ listStyle: "none", m: 0 }}
// 		>
// 			<Box component="li" display="flex" alignItems="center" mx={1}>
// 				<Typography variant="body2">Quality</Typography>
// 			</Box>
// 			{payload.map((entry, index) => {

// 				return (
// 					<MuiTooltip
// 						key={`item-${index}`}
// 						title={`Quantity: ${data[index].Quantity}`}
// 						arrow
// 					>
// 						<Box
// 							component="li"
// 							display="flex"
// 							alignItems="center"
// 							mx={1}
// 							sx={{ cursor: "pointer" }}
// 						>
// 							<Box
// 								sx={{
// 									width: 12,
// 									height: 12,
// 									backgroundColor: entry.color,
// 									mr: 1,
// 								}}
// 							/>
// 							<Typography variant="body2">{entry.value}</Typography>
// 						</Box>
// 					</MuiTooltip>
// 				);
// 			})}
// 		</Box>
// 	);
// };


// const PieChartComponent = ({ chartData, isExpanded = false }) => {
// 	const [showTable, setShowTable] = useState(false);

// 	function toggleView (){
// 		setShowTable(!showTable)
// 	}

// 	// Group data by Quality and sum Quantity
// 	const groupedData = Object.values(
// 		chartData.reduce((acc, item) => {
// 			const { Quality, Quantity } =  item
// 			acc[Quality] = acc[Quality] || { Quality, Quantity: 0 };
// 			acc[Quality].Quantity += Quantity;
// 			if (acc[Quality].items?.length) {
// 				acc[Quality].items.push(item)
// 			} else {
// 				acc[Quality].items  = [item]
// 			}
// 			return acc;
// 		}, {})
// 	);

// 	return (
// 		<Box
// 			sx={{
// 				width: "100%",
// 				height: "100%",
// 				display: "flex",
// 				position: "relative",
// 			}}
// 		>
// 			{isExpanded && (
// 				<IconButton
// 					onClick={toggleView}
// 					sx={{
// 						position: "absolute",
// 						right: "20px",
// 						top: "30px",
// 						cursor: "pointer",
// 						zIndex: 100,
// 					}}
// 				>
// 					<MultipleStopRoundedIcon sx={{ cursor: "pointer" }} />
// 				</IconButton>
// 			)}
// 			<ResponsiveContainer
// 				width={showTable ? "50%" : "100%"}
// 				height={"100%"}
// 				style={{ overflowX: "scroll" }}
// 			>
// 				<PieChart>
// 					<Pie
// 						style={{
// 							position: "relative",
// 							zIndex: 1,
// 							boxShadow:"5px 5px 5px 5px rgba(0, 0, 0, 0.1)"
// 						}}
// 						labelLine={false}
// 						data={groupedData}
// 						cx="50%"
// 						cy="50%"
// 						outerRadius={isExpanded && showTable ? 150 : isExpanded?250:150}
// 						fill="#8884d8"
// 						dataKey="Quantity"
// 						nameKey="Quality"
// 						label={({
// 							cx,
// 							cy,
// 							midAngle,
// 							outerRadius,
// 							percent,
// 							value,
// 							index,
// 						}) => {
// 							const RADIAN = Math.PI / 180;
// 							// Dynamic label positioning based on percentage
// 							const labelRadius = outerRadius + (percent < 0.05 ? 50 : 30);
// 							const x = cx + labelRadius * Math.cos(-midAngle * RADIAN);
// 							const y = cy + labelRadius * Math.sin(-midAngle * RADIAN);
// 							const isRightHalf = midAngle < 90 || midAngle > 270;
// 							const textAnchor = isRightHalf ? "start" : "end";
// 							const labelX = x + (isRightHalf ? 10 : -10);
// 							// Adjust for very small percentages
// 							const labelY = y + (percent < 0.03 ? 0 : 0);

// 							// Custom stepped (staircase) path
// 							const startX = cx + outerRadius * Math.cos(-midAngle * RADIAN);
// 							const startY = cy + outerRadius * Math.sin(-midAngle * RADIAN);
// 							const midX = startX + (x - startX) / 2;
// 							const pathD = `M ${startX} ${startY} H ${midX} V ${y} H ${x}`;

// 							if (percent < 0.02) return null;

// 							return (
// 								<g>
// 									<path
// 										d={pathD}
// 										stroke={COLORS[index]}
// 										strokeWidth={1}
// 										fill="none"
// 									/>
// 									<text
// 										x={labelX}
// 										y={labelY}
// 										fill={COLORS[index]}
// 										textAnchor={textAnchor}
// 										dominantBaseline="central"
// 										style={{
// 											fontSize: percent < 0.05 ? "10px" : "12px",
// 											filter: "drop-shadow(0 1px 1px rgba(0,0,0,0.1))",
// 										}}
// 									>
// 										<tspan x={labelX} dy="0">
// 											{`${(value / 1000).toFixed(2)}K (${(
// 												percent * 100
// 											).toFixed(2)}%)`}
// 										</tspan>
// 									</text>
// 								</g>
// 							);
// 						}}
// 					>
// 						{groupedData.map((entry, index) => (
// 							<Cell
// 								style={{ cursor: "pointer" }}
// 								key={`cell-${index}`}
// 								fill={COLORS[index]}
// 							/>
// 						))}
// 					</Pie>
// 					<Tooltip content={<CustomTooltip />} />
// 					<Legend content={<CustomLegend data={groupedData} />} />
// 				</PieChart>
// 			</ResponsiveContainer>
// 			{showTable && (
// 				<Box sx={{ width: "50%", marginTop: "70px" }}>
// 					<QualityTable data={groupedData} />
// 				</Box>
// 			)}
// 		</Box>
// 	);
// };


// CustomLegend.propTypes = {
// 	payload: PropTypes.array.isRequired,
// 	data:PropTypes.array.isRequired,
// };
// CustomTooltip.propTypes = {
// 	payload: PropTypes.any.isRequired,
// 	active:PropTypes.bool.isRequired
// }
// PieChartComponent.propTypes = {
// 	chartData: PropTypes.array.isRequired,
// 	isExpanded:PropTypes.bool
// };

// export default PieChartComponent;

import React, { useState } from "react";
import {
	PieChart,
	Pie,
	Sector,
	Cell,
	Tooltip,
	Legend,
	ResponsiveContainer,
} from "recharts";
import {
	Box,
	Typography,
	Tooltip as MuiTooltip,
	IconButton,
} from "@mui/material";
import PropTypes from "prop-types";
import MultipleStopRoundedIcon from "@mui/icons-material/MultipleStopRounded";
import QualityTable from "./Parts/QualityTable";

// Generate color dynamically
const COLORS = [
	"#0088FE",
	"#00C49F",
	"#FFBB28",
	"#FF8042",
	"#FF4563",
	"#FF4F63",
	"#FF45F3",
	"#FFF5F3",
];

// Custom active shape to simulate 3D effect on hover
const renderActiveShape = (props) => {
	const {
		cx,
		cy,
		midAngle,
		innerRadius,
		outerRadius,
		startAngle,
		endAngle,
		fill,
		payload,
		value,
		name,
		onClick,
	} = props;
	const RADIAN = Math.PI / 180;
	// Calculate offset for active slice (simulate "pop out")
	const offset = 10;
	const sin = Math.sin(-RADIAN * midAngle);
	const cos = Math.cos(-RADIAN * midAngle);
	const sx = cx + offset * cos;
	const sy = cy + offset * sin;
	// Increase outer radius for active slice
	const activeOuterRadius = outerRadius + 10;

	return (
		<g>
			{/* Render a shadow behind the slice */}
			<Sector
				cx={cx + 5}
				cy={cy + 5}
				innerRadius={innerRadius}
				outerRadius={outerRadius}
				startAngle={startAngle}
				endAngle={endAngle}
				fill={fill}
				opacity={0.3}
				style={{ outline: "none" }}
				tabIndex={-1}
			/>
			{/* Render the active slice */}
			<Sector
				cx={sx}
				cy={sy}
				innerRadius={innerRadius}
				outerRadius={activeOuterRadius}
				startAngle={startAngle}
				endAngle={endAngle}
				style={{ outline: "none" }}
				tabIndex={-1}
				fill={fill}
				onClick={()=>{onClick({ type: "Quality", value:name });}}
			/>
			{/* Render a label on top */}
			<text
				x={sx}
				y={sy}
				dy={8}
				textAnchor="middle"
				fill="#333"
				style={{ fontWeight: "bold" }}
			>
				{payload.name}
			</text>
		</g>
	);
};

const CustomTooltip = ({ active, payload }) => {
	if (active && payload && payload.length) {
		return (
			<div
				style={{
					backgroundColor: "#ffffff",
					padding: "10px",
					border: "1px solid #e2e8f0",
					borderRadius: "8px",
					boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
				}}
			>
				<p style={{ margin: 0, color: "#4A5568" }}>
					Quality: <strong>{payload[0].name}</strong>
				</p>
				<p style={{ margin: 0, color: "#4A5568" }}>
					Quantity: <strong>{payload[0].value}</strong>
				</p>
			</div>
		);
	}
	return null;
};

const CustomLegend = ({ payload = [], data }) => {
	return (
		<Box
			display="flex"
			justifyContent="center"
			p={0}
			component="ul"
			sx={{ listStyle: "none", m: 0 }}
		>
			<Box component="li" display="flex" alignItems="center" mx={1}>
				<Typography variant="body2">Quality</Typography>
			</Box>
			{payload.map((entry, index) => (
				<MuiTooltip
					key={`item-${index}`}
					title={`Quantity: ${data[index].Quantity}`}
					arrow
				>
					<Box
						component="li"
						display="flex"
						alignItems="center"
						mx={1}
						sx={{ cursor: "pointer" }}
					>
						<Box
							sx={{
								width: 12,
								height: 12,
								backgroundColor: COLORS[index],
								mr: 1,
							}}
						/>
						<Typography variant="body2">{entry.value}</Typography>
					</Box>
				</MuiTooltip>
			))}
		</Box>
	);
};

const PieChartComponent = ({ chartData, isExpanded = false, onClick }) => {
	const [showTable, setShowTable] = useState(false);
	const [activeIndex, setActiveIndex] = useState(0);

	function toggleView() {
		setShowTable(!showTable);
	}

	// Group data by Quality and sum Quantity
	const groupedData = Object.values(
		chartData.reduce((acc, item) => {
			const { Quality, Quantity } = item;
			if (!acc[Quality]) {
				acc[Quality] = { Quality, Quantity: 0, items: [] };
			}
			acc[Quality].Quantity += Quantity;
			acc[Quality].items.push(item);
			return acc;
		}, {})
	);

	// Handler for mouse hover on a pie slice
	const onPieEnter = (_, index) => {
		setActiveIndex(index);
	};

	return (
		<Box
			sx={{
				width: "100%",
				height: "100%",
				display: "flex",
				position: "relative",
			}}
		>
			{isExpanded && (
				<IconButton
					onClick={toggleView}
					sx={{
						position: "absolute",
						right: "20px",
						top: "30px",
						cursor: "pointer",
						zIndex: 100,
					}}
				>
					<MultipleStopRoundedIcon />
				</IconButton>
			)}
			<ResponsiveContainer
				width={showTable ? "50%" : "100%"}
				height={"100%"}
				style={{ overflowX: "scroll", outline: "none", border: "none" }}
			>
				<PieChart>
					<Pie
						activeIndex={activeIndex}
						activeShape={(e) => renderActiveShape({ ...e, onClick })}
						onMouseEnter={onPieEnter}
						labelLine={false}
						data={groupedData}
						cx="50%"
						cy="50%"
						outerRadius={isExpanded && showTable ? 150 : isExpanded ? 250 : 150}
						fill="#8884d8"
						dataKey="Quantity"
						nameKey="Quality"
						label={({
							cx,
							cy,
							midAngle,
							outerRadius,
							percent,
							value,
							index,
						}) => {
							const RADIAN = Math.PI / 180;
							const labelRadius = outerRadius + (percent < 0.05 ? 50 : 30);
							const x = cx + labelRadius * Math.cos(-midAngle * RADIAN);
							const y = cy + labelRadius * Math.sin(-midAngle * RADIAN);
							const isRightHalf = midAngle < 90 || midAngle > 270;
							const textAnchor = isRightHalf ? "start" : "end";
							const labelX = x + (isRightHalf ? 10 : -10);
							if (percent < 0.02) return null;
							return (
								<g>
									<path
										d={`M ${cx + outerRadius * Math.cos(-midAngle * RADIAN)} ${
											cy + outerRadius * Math.sin(-midAngle * RADIAN)
										} L ${labelX} ${y}`}
										stroke={COLORS[index]}
										strokeWidth={1}
										fill="none"
									/>
									<text
										x={labelX}
										y={y}
										fill={COLORS[index]}
										textAnchor={textAnchor}
										dominantBaseline="central"
										style={{
											fontSize: percent < 0.05 ? "10px" : "12px",
											filter: "drop-shadow(0 1px 1px rgba(0,0,0,0.1))",
										}}
									>
										<tspan>{`${(value / 1000).toFixed(2)}K (${(
											percent * 100
										).toFixed(2)}%)`}</tspan>
									</text>
								</g>
							);
						}}
					>
						{groupedData.map((entry, index) => (
							<Cell
								key={`cell-${index}`}
								fill={COLORS[index]}
								style={{ cursor: "pointer" }}
							/>
						))}
					</Pie>
					<Tooltip content={<CustomTooltip />} />
					<Legend content={<CustomLegend data={groupedData} />} />
				</PieChart>
			</ResponsiveContainer>
			{showTable && (
				<Box sx={{ width: "50%", marginTop: "70px" }}>
					<QualityTable data={groupedData} />
				</Box>
			)}
		</Box>
	);
};

CustomLegend.propTypes = {
	payload: PropTypes.array.isRequired,
	data: PropTypes.array.isRequired,
};
CustomTooltip.propTypes = {
	payload: PropTypes.any.isRequired,
	active: PropTypes.bool.isRequired,
};
PieChartComponent.propTypes = {
	chartData: PropTypes.array.isRequired,
	isExpanded: PropTypes.bool,
};

export default PieChartComponent;

// import React, { useState } from "react";
// import {
// 	PieChart,
// 	Pie,
// 	Cell,
// 	Tooltip,
// 	Legend,
// 	ResponsiveContainer,
// 	Sector,
// } from "recharts";
// import {
// 	Box,
// 	Typography,
// 	Tooltip as MuiTooltip,
// 	IconButton,
// } from "@mui/material";
// import PropTypes from "prop-types";
// import MultipleStopRoundedIcon from "@mui/icons-material/MultipleStopRounded";
// import QualityTable from "./Parts/QualityTable";

// // Define color palette
// const COLORS = [
// 	"#0088FE",
// 	"#00C49F",
// 	"#FFBB28",
// 	"#FF8042",
// 	"#FF4563",
// 	"#FF4F63",
// 	"#FF45F3",
// 	"#FFF5F3",
// ];

// // Custom active shape to simulate a 3D "pop-out" effect on hover
// const renderActiveShape = (props) => {
// 	const {
// 		cx,
// 		cy,
// 		midAngle,
// 		innerRadius,
// 		outerRadius,
// 		startAngle,
// 		endAngle,
// 		fill,
// 		payload,
// 	} = props;
// 	const RADIAN = Math.PI / 180;
// 	const offset = 10; // offset for active slice
// 	const sin = Math.sin(-RADIAN * midAngle);
// 	const cos = Math.cos(-RADIAN * midAngle);
// 	const sx = cx + offset * cos;
// 	const sy = cy + offset * sin;
// 	const activeOuterRadius = outerRadius + 10;
// 	return (
// 		<g>
// 			{/* Shadow layer */}
// 			<Sector
// 				cx={cx + 5}
// 				cy={cy + 5}
// 				innerRadius={innerRadius}
// 				outerRadius={outerRadius}
// 				startAngle={startAngle}
// 				endAngle={endAngle}
// 				fill={fill}
// 				opacity={0.3}
// 			/>
// 			{/* Active slice */}
// 			<Sector
// 				cx={sx}
// 				cy={sy}
// 				innerRadius={innerRadius}
// 				outerRadius={activeOuterRadius}
// 				startAngle={startAngle}
// 				endAngle={endAngle}
// 				fill={fill}
// 			/>
// 			{/* Label */}
// 			<text
// 				x={sx}
// 				y={sy}
// 				dy={8}
// 				textAnchor="middle"
// 				fill="#333"
// 				style={{ fontWeight: "bold" }}
// 			>
// 				{payload.name}
// 			</text>
// 		</g>
// 	);
// };

// renderActiveShape.propTypes = {
// 	cx: PropTypes.number,
// 	cy: PropTypes.number,
// 	midAngle: PropTypes.number,
// 	innerRadius: PropTypes.number,
// 	outerRadius: PropTypes.number,
// 	startAngle: PropTypes.number,
// 	endAngle: PropTypes.number,
// 	fill: PropTypes.string,
// 	payload: PropTypes.object,
// };

// // Custom Tooltip (unchanged)
// const CustomTooltip = ({ active, payload }) => {
// 	if (active && payload && payload.length) {
// 		return (
// 			<div
// 				style={{
// 					backgroundColor: "#ffffff",
// 					padding: "10px",
// 					border: "1px solid #e2e8f0",
// 					borderRadius: "8px",
// 					boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
// 				}}
// 			>
// 				<p style={{ margin: 0, color: "#4A5568" }}>
// 					Quality: <strong>{payload[0].name}</strong>
// 				</p>
// 				<p style={{ margin: 0, color: "#4A5568" }}>
// 					Quantity: <strong>{payload[0].value}</strong>
// 				</p>
// 			</div>
// 		);
// 	}
// 	return null;
// };

// CustomTooltip.propTypes = {
// 	active: PropTypes.bool.isRequired,
// 	payload: PropTypes.any.isRequired,
// };

// // Custom Legend with interactive toggle and 3D-like styling
// const CustomLegend = ({ data, visibleQualities, onLegendClick }) => {
// 	return (
// 		<Box
// 			display="flex"
// 			justifyContent="center"
// 			p={0}
// 			component="ul"
// 			sx={{ listStyle: "none", m: 0 }}
// 		>
// 			{data.map((entry, index) => {
// 				const isActive = visibleQualities[entry.Quality] !== false;
// 				// If hidden, show gray; else use original color.
// 				const legendColor = isActive ? COLORS[index % COLORS.length] : "#ccc";
// 				return (
// 					<MuiTooltip
// 						key={`legend-${index}`}
// 						title={`Quantity: ${entry.Quantity}`}
// 						arrow
// 					>
// 						<Box
// 							component="li"
// 							onClick={() => onLegendClick(entry.Quality)}
// 							sx={{
// 								cursor: "pointer",
// 								display: "flex",
// 								alignItems: "center",
// 								mx: 1,
// 								opacity: isActive ? 1 : 0.6,
// 								transform: isActive ? "scale(1)" : "scale(0.9)",
// 								transition: "transform 0.2s, opacity 0.2s",
// 								p: 0.5,
// 								borderRadius: "4px",
// 								border: isActive ? "1px solid #ccc" : "1px dashed #aaa",
// 								background: isActive
// 									? "linear-gradient(145deg, #fff, #e6e6e6)"
// 									: "linear-gradient(145deg, #ccc, #aaa)",
// 							}}
// 						>
// 							<Box
// 								sx={{
// 									width: 12,
// 									height: 12,
// 									backgroundColor: legendColor,
// 									mr: 1,
// 									borderRadius: "50%",
// 								}}
// 							/>
// 							<Typography variant="body2">
// 								{entry.Quality} ({entry.Quantity})
// 							</Typography>
// 						</Box>
// 					</MuiTooltip>
// 				);
// 			})}
// 		</Box>
// 	);
// };

// CustomLegend.propTypes = {
// 	data: PropTypes.array.isRequired,
// 	visibleQualities: PropTypes.object.isRequired,
// 	onLegendClick: PropTypes.func.isRequired,
// };

// const PieChartComponent = ({ chartData, isExpanded = false }) => {
// 	const [showTable, setShowTable] = useState(false);
// 	const [activeIndex, setActiveIndex] = useState(0);
// 	// Group data by Quality and sum Quantity; also save items for table
// 	const groupedData = Object.values(
// 		chartData.reduce((acc, item) => {
// 			const { Quality, Quantity } = item;
// 			if (!acc[Quality]) {
// 				acc[Quality] = { Quality, Quantity: 0, items: [] };
// 			}
// 			acc[Quality].Quantity += Quantity;
// 			acc[Quality].items.push(item);
// 			return acc;
// 		}, {})
// 	);

// 	// Initialize visibility for all qualities
// 	const initialVisibility = {};
// 	groupedData.forEach((entry) => {
// 		initialVisibility[entry.Quality] = true;
// 	});
// 	const [visibleQualities, setVisibleQualities] = useState(initialVisibility);

// 	// Filter data based on visible qualities for the chart
// 	const filteredData = groupedData.filter(
// 		(entry) => visibleQualities[entry.Quality] !== false
// 	);

// 	// Toggle visibility when legend item is clicked
// 	const onLegendClick = (quality) => {
// 		setVisibleQualities((prev) => ({
// 			...prev,
// 			[quality]: !prev[quality],
// 		}));
// 	};

// 	// Handler for pie slice hover
// 	const onPieEnter = (_, index) => {
// 		setActiveIndex(index);
// 	};

// 	function toggleView() {
// 		setShowTable(!showTable);
// 	}

// 	return (
// 		<Box
// 			sx={{
// 				width: "100%",
// 				height: "100%",
// 				display: "flex",
// 				position: "relative",
// 			}}
// 		>
// 			{isExpanded && (
// 				<IconButton
// 					onClick={toggleView}
// 					sx={{
// 						position: "absolute",
// 						right: "20px",
// 						top: "30px",
// 						cursor: "pointer",
// 						zIndex: 100,
// 					}}
// 				>
// 					<MultipleStopRoundedIcon />
// 				</IconButton>
// 			)}
// 			<ResponsiveContainer
// 				width={showTable ? "50%" : "100%"}
// 				height={"100%"}
// 				style={{ overflowX: "scroll" }}
// 			>
// 				<PieChart>
// 					<Pie
// 						activeIndex={activeIndex}
// 						activeShape={renderActiveShape}
// 						onMouseEnter={onPieEnter}
// 						labelLine={false}
// 						data={filteredData}
// 						cx="50%"
// 						cy="50%"
// 						outerRadius={isExpanded && showTable ? 150 : isExpanded ? 250 : 150}
// 						fill="#8884d8"
// 						dataKey="Quantity"
// 						nameKey="Quality"
// 						label={({
// 							cx,
// 							cy,
// 							midAngle,
// 							outerRadius,
// 							percent,
// 							value,
// 							index,
// 						}) => {
// 							const RADIAN = Math.PI / 180;
// 							const labelRadius = outerRadius + (percent < 0.05 ? 50 : 30);
// 							const x = cx + labelRadius * Math.cos(-midAngle * RADIAN);
// 							const y = cy + labelRadius * Math.sin(-midAngle * RADIAN);
// 							const isRightHalf = midAngle < 90 || midAngle > 270;
// 							const textAnchor = isRightHalf ? "start" : "end";
// 							const labelX = x + (isRightHalf ? 10 : -10);
// 							if (percent < 0.02) return null;
// 							return (
// 								<g>
// 									<path
// 										d={`M ${cx + outerRadius * Math.cos(-midAngle * RADIAN)} ${
// 											cy + outerRadius * Math.sin(-midAngle * RADIAN)
// 										} L ${labelX} ${y}`}
// 										stroke={COLORS[index]}
// 										strokeWidth={1}
// 										fill="none"
// 									/>
// 									<text
// 										x={labelX}
// 										y={y}
// 										fill={COLORS[index]}
// 										textAnchor={textAnchor}
// 										dominantBaseline="central"
// 										style={{
// 											fontSize: percent < 0.05 ? "10px" : "12px",
// 											filter: "drop-shadow(0 1px 1px rgba(0,0,0,0.1))",
// 										}}
// 									>
// 										<tspan>{`${(value / 1000).toFixed(2)}K (${(
// 											percent * 100
// 										).toFixed(2)}%)`}</tspan>
// 									</text>
// 								</g>
// 							);
// 						}}
// 					>
// 						{filteredData.map((entry, index) => (
// 							<Cell
// 								key={`cell-${index}`}
// 								fill={COLORS[index]}
// 								style={{ cursor: "pointer" }}
// 							/>
// 						))}
// 					</Pie>
// 					<Tooltip content={<CustomTooltip />} />
// 					<Legend
// 						content={
// 							<CustomLegend
// 								data={groupedData}
// 								visibleQualities={visibleQualities}
// 								onLegendClick={onLegendClick}
// 							/>
// 						}
// 					/>
// 				</PieChart>
// 			</ResponsiveContainer>
// 			{showTable && (
// 				<Box sx={{ width: "50%", marginTop: "70px" }}>
// 					<QualityTable data={groupedData} />
// 				</Box>
// 			)}
// 		</Box>
// 	);
// };

// PieChartComponent.propTypes = {
// 	chartData: PropTypes.array.isRequired,
// 	isExpanded: PropTypes.bool,
// };

// export default PieChartComponent;

