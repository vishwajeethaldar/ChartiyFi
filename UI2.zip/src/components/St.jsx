import React from "react";
import {
	BarChart,
	Bar,
	Cell,
	XAxis,
	YAxis,
	CartesianGrid,
	Tooltip,
	Legend,
	ResponsiveContainer,
} from "recharts";

const data = [
	{
		name: "Parcel2",
		value1: 18.64,
		value2: 15.11,
		value3: 16.32,
		value4: 24.51,
	},
	{
		name: "Parcel5",
		value1: 17.87,
		value2: 15.55,
		value3: 15.57,
		value4: 24.45,
	},
];

const StackedBarChart = () => {
	return (
		<ResponsiveContainer width="100%" height={300}>
			<BarChart data={data}>
				<XAxis dataKey="name" />
				<YAxis />
				<CartesianGrid stroke="#f5f5f5" />
				<Tooltip />
				<Legend />
				<Bar dataKey="value1" stackId="a" fill="#6495ED" />
				<Bar dataKey="value2" stackId="a" fill="#FFD700" />
				<Bar dataKey="value3" stackId="a" fill="#FFA07A" />
				<Bar dataKey="value4" stackId="a" fill="#9400D3" />
			</BarChart>
		</ResponsiveContainer>
	);
};

export default StackedBarChart;
