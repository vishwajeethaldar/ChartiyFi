import { useEffect, useState } from "react";
import {
	Box,
	Button,
	Checkbox,
	Chip,
	Grid2 as Grid,
	IconButton,
	List,
	ListItem,
	ListItemButton,
	ListItemIcon,
	ListItemText,
	Paper,
	Typography,
	Modal,
} from "@mui/material";
import {
	ExpandOutlined,
	Close,
	FilterList,
	AutoGraph,
	// StackedBarChart,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";

// Import your components
import DistByQuality from "./components/Charts/DistByQuality";
import StackedBarChartComponent from "./components/Charts/StackedBarChart";
import StackedBarChartBySizeCategoryAndModel from "./components/Charts/StackedBarChartBySizeCategoryAndModel";
import { data } from "./components/data";
import RechartsExample from "./components/Charts/LineChart";
// import ChartDisplayModal from "./components/ChartDisplayModal/ChartDisplayModal";

const StyledPaper = styled(Paper)(({ theme }) => ({
	padding: theme.spacing(3),
	borderRadius: theme.shape.borderRadius * 2,
	transition: "transform 0.2s, box-shadow 0.2s",
	"&:hover": {
		transform: "translateY(-4px)",
		boxShadow: theme.shadows[6],
	},
}));

const ChartContainer = styled(Box)({
	position: "relative",
	height: "400px",
	width: "100%",
});


function App() {
	const [selectedParcels, setSelectedParcels] = useState([]);
	const [selectedDealNames, setSelectedDealNames] = useState([]);
	const [isModalOpen, setIsModalOpen] = useState(false);
	const [openModalTitle, setOpenModalTitle] = useState(false);
	const [activeChart, setActiveChart] = useState(null);
	const [filteredData, setFilteredData] = useState([]);
  	const [isLoading, setIsLoading] = useState(false);
	const [isFilter, setIsFilter] = useState(false);
	
	const toggleParcel = (parcel) => {
		setSelectedParcels((prev) =>
			prev.includes(parcel)
				? prev.filter((p) => p !== parcel)
				: [...prev, parcel]
		);
	};

	const toggleDealName = (dealName) => {
		setSelectedDealNames((prev) =>
			prev.includes(dealName)
				? prev.filter((p) => p !== dealName)
				: [...prev, dealName]
		);
	};

	const openModal = (chart, title) => {
		setActiveChart(chart);
		setIsModalOpen(true);
		setOpenModalTitle(title);
	};

	const closeModal = () => {
		setIsModalOpen(false);
		setActiveChart(null);
		setOpenModalTitle("")
	};


	const filterKeys = [...new Set(data.map((item) => item.ParcelName))];
	const filterDealNames = [...new Set(data.map((item) => item.DealName))];

	useEffect(() => {
		if (data.length) {
			setFilteredData(data);
		}
	}, []);

	function handleClick(filter) {
		if (filteredData.length) {
			setFilteredData((prevData) =>
				prevData.filter((item) => item[filter.type] === filter.value)
			);	
			setIsFilter(true);
		}
	}
	function clearFilter() {
		setFilteredData(data);
		setIsFilter(false);
	}
	
	const applyFilter = () => {
		setIsLoading(true);

		// Allow UI to update before heavy computation
		setTimeout(() => {
			const filterStartTime = performance.now();

			let result;
			if (selectedParcels.length > 0 || selectedDealNames.length>0) {
				      result = data.filter((item) => {
								const parcelMatch =
									selectedParcels.length > 0
										? selectedParcels.includes(item.ParcelName)
										: true;
								const dealNameMatch =
									selectedDealNames.length > 0
										? selectedDealNames.includes(item.DealName)
										: true;
								return parcelMatch && dealNameMatch;
							});

			} else {
				result = [...data];
			}

			// Simulate minimum loading time for smooth UX
			const minLoadTime = 500;
			const elapsed = performance.now() - filterStartTime;
			const remainingDelay = Math.max(minLoadTime - elapsed, 0);

			setTimeout(() => {
				setFilteredData(result);
				setIsLoading(false);
			}, remainingDelay);
		}, 0);
	};



	return (
		<Box
			sx={{
				display: "flex",
				minHeight: "100vh",
				p: 3,
				gap: 3,
				position: "relative",
			}}
		>
			{/* Filter Sidebar */}
			{/* <Paper sx={{ width: 280, p: 2, position: "sticky", top: 16 }}>
				<Box sx={{ display: "flex", alignItems: "center", mb: 2, gap: 1 }}>
					<FilterList color="primary" />
					<Typography variant="h6">Filters</Typography>
					{selectedParcels.length > 0 && (
						<Chip
							label="Clear"
							color="error"
							variant="outlined"
							onClick={() => setSelectedParcels([])}
							size="small"
						/>
					)}
				</Box>

				<List dense sx={{ maxHeight: "70vh", overflow: "auto" }}>
					{filterKeys.map((parcel) => (
						<ListItem key={parcel} disablePadding>
							<ListItemButton onClick={() => toggleParcel(parcel)}>
								<ListItemIcon>
									<Checkbox
										edge="start"
										checked={selectedParcels.includes(parcel)}
										tabIndex={-1}
										disableRipple
									/>
								</ListItemIcon>
								<ListItemText primary={parcel} />
							</ListItemButton>
						</ListItem>
					))}
				</List>

				<Button
					fullWidth
					variant="contained"
					onClick={applyFilter}
					startIcon={<AutoGraph />}
					sx={{ mt: 2 }}
				>
					{isLoading ? "Applying Filters..." : "Apply Filters"}
				</Button>
			</Paper> */}
			<Paper sx={{ width: 280, p: 2, position: "sticky", top: 16 }}>
				<Box sx={{ display: "flex", alignItems: "center", mb: 2, gap: 1 }}>
					<FilterList color="primary" />
					<Typography variant="h6">Filters</Typography>
					{selectedParcels.length > 0 && (
						<Chip
							label="Clear"
							color="error"
							variant="outlined"
							onClick={() => setSelectedParcels([])}
							size="small"
						/>
					)}
				</Box>

				{/* Parcel Filters */}
				<Typography variant="subtitle1" sx={{ mb: 1 }}>
					Parcel Filters
				</Typography>
				<List dense sx={{ maxHeight: "35vh", overflow: "auto" }}>
					{filterKeys.map((parcel) => (
						<ListItem key={parcel} disablePadding>
							<ListItemButton onClick={() => toggleParcel(parcel)}>
								<ListItemIcon>
									<Checkbox
										edge="start"
										checked={selectedParcels.includes(parcel)}
										tabIndex={-1}
										disableRipple
									/>
								</ListItemIcon>
								<ListItemText primary={parcel} />
							</ListItemButton>
						</ListItem>
					))}
				</List>

				{/* Deal Name Filters */}
				<Typography variant="subtitle1" sx={{ mt: 2, mb: 1 }}>
					Deal Name
				</Typography>
				<List dense sx={{ maxHeight: "35vh", overflow: "auto" }}>
					{filterDealNames.map((dealName) => (
						<ListItem key={dealName} disablePadding>
							<ListItemButton onClick={() => toggleDealName(dealName)}>
								<ListItemIcon>
									<Checkbox
										edge="start"
										checked={selectedDealNames.includes(dealName)}
										tabIndex={-1}
										disableRipple
									/>
								</ListItemIcon>
								<ListItemText primary={dealName} />
							</ListItemButton>
						</ListItem>
					))}
				</List>

				<Button
					fullWidth
					variant="contained"
					onClick={applyFilter}
					startIcon={<AutoGraph />}
					sx={{ mt: 2 }}
				>
					{isLoading ? "Applying Filters..." : "Apply Filters"}
				</Button>
			</Paper>

			{/* Main Content */}
			<Box
				sx={{
					flex: 1,
					display: "flex",
					flexDirection: "column",
					gap: 3,
					maxHeight: "95vh",
					overflow: "scroll",
				}}
			>
				<Typography
					variant="h4"
					component="h1"
					sx={{
						fontWeight: 600,
						position: "sticky",
						top: 0,
						zIndex: 1000,
						backgroundColor: "#fff",
					}}
				>
					Dashboard
				</Typography>
				{isFilter && <Button
					fullWidth
					variant="contained"
					onClick={clearFilter}
					startIcon={<AutoGraph />}
					sx={{ mt: 2, position: "absolute", top: "10px", right: "10px", zIndex:1001, width:"200px" }}
				>
					{ "Clear filter"}
				</Button>}
				<Grid container spacing={3}>
					<Grid size={[12, 6]}>
						<StyledPaper>
							<Box
								sx={{
									display: "flex",
									justifyContent: "space-between",
									alignItems: "center",
									mb: 2,
								}}
							>
								<Typography variant="h6">Quality Distribution</Typography>
								<IconButton
									onClick={() =>
										openModal(
											<DistByQuality
												chartData={filteredData}
												isExpanded={true}
												onClick={handleClick}
											/>,
											"Quality Distribution"
										)
									}
								>
									<ExpandOutlined />
								</IconButton>
							</Box>
							<ChartContainer>
								<DistByQuality chartData={filteredData} onClick={handleClick} />
							</ChartContainer>
						</StyledPaper>
					</Grid>

					<Grid size={[12, 6]}>
						<StyledPaper>
							<Box
								sx={{
									display: "flex",
									justifyContent: "space-between",
									alignItems: "center",
									mb: 2,
								}}
							>
								<Typography variant="h6">Carats by Size & Color</Typography>
								<IconButton
									onClick={() =>
										openModal(
											<StackedBarChartComponent
												chartData={filteredData}
												isExpanded={true}
											/>,
											"Carats by Size & Color"
										)
									}
								>
									<ExpandOutlined />
								</IconButton>
							</Box>
							<ChartContainer>
								<StackedBarChartComponent chartData={filteredData} />
							</ChartContainer>
						</StyledPaper>
					</Grid>

					<Grid size={[12, 6]}>
						<StyledPaper>
							<Box
								sx={{
									display: "flex",
									justifyContent: "space-between",
									alignItems: "center",
									mb: 2,
								}}
							>
								<Typography variant="h6">
									Carats by Size Category & Model
								</Typography>
								<IconButton
									onClick={() =>
										openModal(
											<StackedBarChartBySizeCategoryAndModel
												chartData={filteredData}
												isExpanded={true}
											/>,
											"Carats by Size Category & Model"
										)
									}
								>
									<ExpandOutlined />
								</IconButton>
							</Box>
							<ChartContainer sx={{ height: 500 }}>
								<StackedBarChartBySizeCategoryAndModel
									chartData={filteredData}
								/>
							</ChartContainer>
						</StyledPaper>
					</Grid>
					<Grid size={[12, 6]}>
						<StyledPaper>
							<Box
								sx={{
									display: "flex",
									justifyContent: "space-between",
									alignItems: "center",
									mb: 2,
								}}
							>
								<Typography variant="h6">
									Monthly Average of PricePerCarat
								</Typography>
								<IconButton
									onClick={() =>
										openModal(
											<RechartsExample data={filteredData} isExpanded={true} />,
											"Monthly Average of PricePerCarat"
										)
									}
								>
									<ExpandOutlined />
								</IconButton>
							</Box>
							<ChartContainer sx={{ height: 500 }}>
								<RechartsExample data={filteredData} />
							</ChartContainer>
						</StyledPaper>
					</Grid>
				</Grid>
			</Box>

			{/* Modal */}
			<Modal open={isModalOpen} onClose={closeModal}>
				<Box
					sx={{
						position: "absolute",
						top: "50%",
						left: "50%",
						transform: "translate(-50%, -50%)",
						width: "90vw",
						height: "90vh",
						bgcolor: "background.paper",
						borderRadius: 2,
						boxShadow: 24,
						p: 4,
					}}
				>
					<IconButton
						onClick={closeModal}
						sx={{ position: "absolute", right: 16, top: 16 }}
					>
						<Close />
					</IconButton>
					<Typography variant="h5" textAlign={"center"}>
						{openModalTitle}
					</Typography>
					<Box sx={{ height: "calc(100% - 32px)", mt: 4 }}>{activeChart}</Box>
				</Box>
			</Modal>
		</Box>
	);
}

export default App;